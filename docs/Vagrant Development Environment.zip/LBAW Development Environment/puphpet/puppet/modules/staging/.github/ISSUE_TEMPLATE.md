Please check the following items before submitting an issue -- thank you!

Nnote that this project is released with a Contributor Code of Conduct.
By participating in this project you agree to abide by its terms.
[Contributor Code of Conduct](https://voxpupuli.org/coc/).

- [ ] There is no existing issue or PR that addresses this problem

Optional, but makes our lives much easier:

- [ ] The issue affects the latest release of this module at the time of
  submission

- - -

### Affected Puppet, Ruby, OS and module versions/distributions

### What are you seeing

### What behaviour did you expect instead

### How did this behaviour get triggered

### Output log

### Any additional information you'd like to impart
